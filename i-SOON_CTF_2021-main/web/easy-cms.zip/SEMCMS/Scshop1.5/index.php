<?php
session_start();
include_once  'Core/Program/Include.php';
include_once  'Template/Default/File/Function.php';
include_once  'Template/Default/File/default.php';
?>