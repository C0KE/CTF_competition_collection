<?php
// CopyRight © semcms (QQ:1181698019【黑蚂蚁.阿梁】)
// website:https://www.sem-cms.cn/
include_once 'db_con.php';
include_once 'Ant_Check.php';
include_once 'Ant_Class.php';
include_once 'Ant_Contrl.php';
include_once 'class.phpmailer.php'; 
include_once 'Ant_Config.php';
include_once 'Ant_Shop.php';