#!/bin/sh

echo $FLAG > /flag # 将flag写入根目录

export FLAG=not_flag
FLAG=not_flag

rm -f /flag.sh